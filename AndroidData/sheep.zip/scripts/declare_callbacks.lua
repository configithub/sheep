function spawn_bombs()
  returnCode = spawn_entity(1, 440, 340, 1, 460, 360, 1, 420, 360)
end
