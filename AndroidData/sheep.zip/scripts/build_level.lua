--returnCode = spawn_entity(0, 40, 40, 0, 60, 60, 0, 90, 120)
--spawn_entity(4 , 460, 120) -- entity 10
--entity_patrol(7, 460, 40, 460, 120)

