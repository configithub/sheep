--returnCode = spawn_entity(0, 40, 40, 0, 60, 60, 0, 90, 120)
spawn_entity(4 , 40, 80) -- entity 10
entity_patrol(7, 80, 180, 140, 220, 230, 50)

