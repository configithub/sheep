sed -i "s/c/07:02/g" $1
sed -i "s/b/01:02/g" $1
sed -i "s/v/15:01/g" $1
sed -i "s/l/08:02/g" $1
sed -i "s/r/06:02/g" $1
sed -i "s/t/13:02/g" $1
